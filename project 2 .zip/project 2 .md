This dataset is based on "Bank Marketing" . The goal of this problem is to build a predictive model to predict whether a bank customer will subscribe to a term deposit or not. 
i explore the data and describe any insights found in the data also check the correlation to know the variables that are high.
i  check the Missing rows less than 50% of the data and then dropped it  with reasonable explanation for my intuition. 
i did Several visualizations to explain my  insight on my dataset.
i split my model into train and test split.
i build my model with series of models
i use logistic regression, decision tree, random forest, knneigbhour. 
I build my model on imbalanced data and a balanced data to know how well my  model can work. 
on the balanced and imblanaced data on logistic. my result is Train accuracy: 0.9056
Validation accuracy: 0.9092 for imbalance data and on balanced data, Train accuracy: 0.9340
Validation accuracy: 0.9351.On decision tree: Train accuracy: 0.9120
Validation accuracy: 0.9107, while on balance data we have Train accuracy: 0.8681
Validation accuracy: 0.8671. on random forest:Train accuracy: 0.9878
Validation accuracy: 0.9031 on balanced data: Train accuracy: 0.9934
Validation accuracy: 0.9404. on knneigbhour: Train accuracy: 0.9179
Validation accuracy: 0.8965 on balanced data: Train accuracy: 0.9451
Validation accuracy: 0.9327
i did hyperparameter tunning on my model, by using the best model which is the logistic regression. on the balance data and also on the imbalance data. 

i use the gridsearch to fine tune my model and i get the  best parameters to use to rebuild my model with the x test. 

i use the classification_report, f1_score, recall_score, precision_score, confusion_matrix

and my final result on classification_report: 
              precision    recall  f1-score   support

           0       0.94      0.94      0.94      9017
           1       0.94      0.94      0.94      9257

    accuracy                           0.94     18274
   macro avg       0.94      0.94      0.94     18274
weighted avg       0.94      0.94      0.94     18274

# LOAD THE DATA


```python
#load the data and show the data 
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import seaborn as sns 

path = r'C:\Users\USER\Desktop\bank_data.csv\bank_data.csv'

data = pd.read_csv(path)
```


```python
data.head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>job</th>
      <th>marital</th>
      <th>education</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>campaign</th>
      <th>pdays</th>
      <th>previous</th>
      <th>poutcome</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>housemaid</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>3</th>
      <td>40</td>
      <td>admin.</td>
      <td>married</td>
      <td>basic.6y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>4</th>
      <td>56</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>5</th>
      <td>45</td>
      <td>services</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>6</th>
      <td>59</td>
      <td>admin.</td>
      <td>married</td>
      <td>professional.course</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>7</th>
      <td>41</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>8</th>
      <td>24</td>
      <td>technician</td>
      <td>single</td>
      <td>professional.course</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>9</th>
      <td>25</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>10</th>
      <td>41</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>11</th>
      <td>25</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>12</th>
      <td>29</td>
      <td>blue-collar</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>13</th>
      <td>57</td>
      <td>housemaid</td>
      <td>divorced</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>14</th>
      <td>35</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.6y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>15</th>
      <td>54</td>
      <td>retired</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>NaN</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>16</th>
      <td>35</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.6y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>17</th>
      <td>46</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.6y</td>
      <td>NaN</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>18</th>
      <td>50</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>19</th>
      <td>39</td>
      <td>management</td>
      <td>single</td>
      <td>basic.9y</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>20</th>
      <td>30</td>
      <td>unemployed</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>21</th>
      <td>55</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>NaN</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>22</th>
      <td>55</td>
      <td>retired</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>23</th>
      <td>41</td>
      <td>technician</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>24</th>
      <td>37</td>
      <td>admin.</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>25</th>
      <td>35</td>
      <td>technician</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>26</th>
      <td>59</td>
      <td>technician</td>
      <td>married</td>
      <td>NaN</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>27</th>
      <td>39</td>
      <td>self-employed</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>28</th>
      <td>54</td>
      <td>technician</td>
      <td>single</td>
      <td>university.degree</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>2</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>29</th>
      <td>55</td>
      <td>NaN</td>
      <td>married</td>
      <td>university.degree</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>30</th>
      <td>46</td>
      <td>admin.</td>
      <td>married</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>31</th>
      <td>59</td>
      <td>technician</td>
      <td>married</td>
      <td>NaN</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>32</th>
      <td>49</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>33</th>
      <td>54</td>
      <td>management</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>NaN</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>34</th>
      <td>54</td>
      <td>blue-collar</td>
      <td>divorced</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>35</th>
      <td>55</td>
      <td>NaN</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>NaN</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>36</th>
      <td>34</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>37</th>
      <td>52</td>
      <td>technician</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>38</th>
      <td>41</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>39</th>
      <td>56</td>
      <td>technician</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>40</th>
      <td>58</td>
      <td>management</td>
      <td>NaN</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>41</th>
      <td>32</td>
      <td>entrepreneur</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>42</th>
      <td>38</td>
      <td>admin.</td>
      <td>single</td>
      <td>professional.course</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>43</th>
      <td>57</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>44</th>
      <td>44</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>NaN</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>45</th>
      <td>42</td>
      <td>technician</td>
      <td>single</td>
      <td>professional.course</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>46</th>
      <td>57</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>47</th>
      <td>40</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>48</th>
      <td>35</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>49</th>
      <td>45</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>2</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
  </tbody>
</table>
<p>50 rows × 21 columns</p>
</div>




```python
#Get the shape of the data 
data.shape
```




    (41188, 21)




```python
# Get the correlation of the data 
data.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>duration</th>
      <th>campaign</th>
      <th>pdays</th>
      <th>previous</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>age</th>
      <td>1.000000</td>
      <td>-0.000866</td>
      <td>0.004594</td>
      <td>-0.034369</td>
      <td>0.024365</td>
      <td>-0.000371</td>
      <td>0.000857</td>
      <td>0.129372</td>
      <td>0.010767</td>
      <td>-0.017725</td>
    </tr>
    <tr>
      <th>duration</th>
      <td>-0.000866</td>
      <td>1.000000</td>
      <td>-0.071699</td>
      <td>-0.047577</td>
      <td>0.020640</td>
      <td>-0.027968</td>
      <td>0.005312</td>
      <td>-0.008173</td>
      <td>-0.032897</td>
      <td>-0.044703</td>
    </tr>
    <tr>
      <th>campaign</th>
      <td>0.004594</td>
      <td>-0.071699</td>
      <td>1.000000</td>
      <td>0.052584</td>
      <td>-0.079141</td>
      <td>0.150754</td>
      <td>0.127836</td>
      <td>-0.013733</td>
      <td>0.135133</td>
      <td>0.144095</td>
    </tr>
    <tr>
      <th>pdays</th>
      <td>-0.034369</td>
      <td>-0.047577</td>
      <td>0.052584</td>
      <td>1.000000</td>
      <td>-0.587514</td>
      <td>0.271004</td>
      <td>0.078889</td>
      <td>-0.091342</td>
      <td>0.296899</td>
      <td>0.372605</td>
    </tr>
    <tr>
      <th>previous</th>
      <td>0.024365</td>
      <td>0.020640</td>
      <td>-0.079141</td>
      <td>-0.587514</td>
      <td>1.000000</td>
      <td>-0.420489</td>
      <td>-0.203130</td>
      <td>-0.050936</td>
      <td>-0.454494</td>
      <td>-0.501333</td>
    </tr>
    <tr>
      <th>emp.var.rate</th>
      <td>-0.000371</td>
      <td>-0.027968</td>
      <td>0.150754</td>
      <td>0.271004</td>
      <td>-0.420489</td>
      <td>1.000000</td>
      <td>0.775334</td>
      <td>0.196041</td>
      <td>0.972245</td>
      <td>0.906970</td>
    </tr>
    <tr>
      <th>cons.price.idx</th>
      <td>0.000857</td>
      <td>0.005312</td>
      <td>0.127836</td>
      <td>0.078889</td>
      <td>-0.203130</td>
      <td>0.775334</td>
      <td>1.000000</td>
      <td>0.058986</td>
      <td>0.688230</td>
      <td>0.522034</td>
    </tr>
    <tr>
      <th>cons.conf.idx</th>
      <td>0.129372</td>
      <td>-0.008173</td>
      <td>-0.013733</td>
      <td>-0.091342</td>
      <td>-0.050936</td>
      <td>0.196041</td>
      <td>0.058986</td>
      <td>1.000000</td>
      <td>0.277686</td>
      <td>0.100513</td>
    </tr>
    <tr>
      <th>euribor3m</th>
      <td>0.010767</td>
      <td>-0.032897</td>
      <td>0.135133</td>
      <td>0.296899</td>
      <td>-0.454494</td>
      <td>0.972245</td>
      <td>0.688230</td>
      <td>0.277686</td>
      <td>1.000000</td>
      <td>0.945154</td>
    </tr>
    <tr>
      <th>nr.employed</th>
      <td>-0.017725</td>
      <td>-0.044703</td>
      <td>0.144095</td>
      <td>0.372605</td>
      <td>-0.501333</td>
      <td>0.906970</td>
      <td>0.522034</td>
      <td>0.100513</td>
      <td>0.945154</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



These show the correlation on the data set, those that to be use and not to be used to build the model. 
i obesrve that,  emp.var.rate, euribor3m, nr.employed has a highest correlation.


```python
# Check if there is missing number on the dataset. 

data.isnull().sum()
```




    age                  0
    job                330
    marital             80
    education         1731
    default           8597
    housing            990
    loan               990
    contact              0
    month                0
    day_of_week          0
    duration             0
    campaign             0
    pdays                0
    previous             0
    poutcome             0
    emp.var.rate         0
    cons.price.idx       0
    cons.conf.idx        0
    euribor3m            0
    nr.employed          0
    y                    0
    dtype: int64



i checked to know if there are missing values.


```python
#spliting the features to vizualise our dataset. 

data_1= data[data['y'] == 'no']
data_2 = data[data['y'] == 'yes']
```

i split y to visiualize my dataset, to know who subscribe to term deposit and who do not subcribe. 


```python
data_1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>job</th>
      <th>marital</th>
      <th>education</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>campaign</th>
      <th>pdays</th>
      <th>previous</th>
      <th>poutcome</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>housemaid</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>3</th>
      <td>40</td>
      <td>admin.</td>
      <td>married</td>
      <td>basic.6y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>4</th>
      <td>56</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>41180</th>
      <td>36</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>cellular</td>
      <td>nov</td>
      <td>fri</td>
      <td>...</td>
      <td>2</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>-1.1</td>
      <td>94.767</td>
      <td>-50.8</td>
      <td>1.028</td>
      <td>4963.6</td>
      <td>no</td>
    </tr>
    <tr>
      <th>41182</th>
      <td>29</td>
      <td>unemployed</td>
      <td>single</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>cellular</td>
      <td>nov</td>
      <td>fri</td>
      <td>...</td>
      <td>1</td>
      <td>9</td>
      <td>1</td>
      <td>success</td>
      <td>-1.1</td>
      <td>94.767</td>
      <td>-50.8</td>
      <td>1.028</td>
      <td>4963.6</td>
      <td>no</td>
    </tr>
    <tr>
      <th>41184</th>
      <td>46</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>professional.course</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>cellular</td>
      <td>nov</td>
      <td>fri</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>-1.1</td>
      <td>94.767</td>
      <td>-50.8</td>
      <td>1.028</td>
      <td>4963.6</td>
      <td>no</td>
    </tr>
    <tr>
      <th>41185</th>
      <td>56</td>
      <td>retired</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>cellular</td>
      <td>nov</td>
      <td>fri</td>
      <td>...</td>
      <td>2</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>-1.1</td>
      <td>94.767</td>
      <td>-50.8</td>
      <td>1.028</td>
      <td>4963.6</td>
      <td>no</td>
    </tr>
    <tr>
      <th>41187</th>
      <td>74</td>
      <td>retired</td>
      <td>married</td>
      <td>professional.course</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>cellular</td>
      <td>nov</td>
      <td>fri</td>
      <td>...</td>
      <td>3</td>
      <td>999</td>
      <td>1</td>
      <td>failure</td>
      <td>-1.1</td>
      <td>94.767</td>
      <td>-50.8</td>
      <td>1.028</td>
      <td>4963.6</td>
      <td>no</td>
    </tr>
  </tbody>
</table>
<p>36548 rows × 21 columns</p>
</div>




```python
#A plot to know the no of employers who advert the subscription to customer quaterly. 
plt.hist(data['nr.employed'])
plt.title('total nr.employed')
plt.show()
```


    
![png](output_12_0.png)
    


This plot shows how the number of employee that actually advert the product,
we have the employee who did well in adverting the term deposit and around 5200 employee got 16,000 customers to subcribe. 


```python
# A plot to know how many of the customers who subscribe to term deposit daily. 

plt.hist(data['euribor3m'])
plt.title('total euribor3m')

plt.show()
```


    
![png](output_14_0.png)
    


This plot shows how many customers subcribe to term deposit daily. 
from the plot, we understand that amount 5 percent of the subscribers paid 25000 naira daily. 


```python
plt.hist(data['cons.conf.idx'])
plt.xlabel('consumer confidence')
plt.title('consumer confidence')
plt.show()
```


    
![png](output_16_0.png)
    


This plot shows the confidence the consumer have on a montly basis, the strength for them to put their money into term deposit. 
and from the plot we see that almost 40 comsumers put the highest amount of money. which means, 
they solely have good confidence on the term deposit. 


```python
# A plot to know how much customer willing to subcribe for the term deposit. 

plt.hist(data['cons.price.idx'], color = 'green')
plt.xlabel('consumer price')
plt.title('consumer price')
plt.show()
```


    
![png](output_18_0.png)
    


This is the percent of the customers who wilingly to safe or to subcribe to term deposit. almost 94 percent of the customer subscribe more than 14000. this shows a great deal. 


```python
# This plot explained the rate and who really subscribe to the term deposit. 

data_single = data[data['marital'] =='single']
data_married = data[data['marital'] == 'married']
data_divorced = data[data['marital'] == 'divorced']


plt.boxplot([data_single['euribor3m'], data_married['euribor3m'], data_divorced['euribor3m']], labels = ['single', 'married', 'divorced'], data= 'y')
plt.xlabel('marital')
plt.ylabel('euribor3m')
plt.show()
```


    
![png](output_20_0.png)
    


This plot shows the marital status who subcribe to the term deposit. 
we obesrve that single low, and while the married status and divorced status subscribe more to the term deposit. 


```python
# this plot shows how confident customer have, to subcribe to the term deposit. 
plt.boxplot([data_single['cons.conf.idx'], data_married['cons.conf.idx'], data_divorced['cons.conf.idx']], labels = ['single', 'married', 'divorced'], data= 'y')
plt.xlabel('marital')
plt.ylabel('cons.conf.idx')
plt.show()
```


    
![png](output_22_0.png)
    


This plot shows the confident each of the marital status have on the term deposit. the single have low cofident and while the married status and the divorced status want to safe their money into term deposit


```python
#This plot shows who put the highest amount to the term deposit. 
plt.boxplot([data_single['cons.price.idx'], data_married['cons.price.idx'], data_divorced['cons.price.idx']], labels = ['single', 'married', 'divorced'], data= 'y')
plt.xlabel('marital')
plt.ylabel('cons.price.idx')
plt.show()
```


    
![png](output_24_0.png)
    


This plot shows that the single start subcribing and whith a little amount of money, while the married and divorced status put more money to the term deposit


```python
# This shows how employee drive the campaign for term deposit.
sns.distplot(data['nr.employed'], hist = False)
plt.show
```

    C:\Users\USER\anaconda3\lib\site-packages\seaborn\distributions.py:2551: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `kdeplot` (an axes-level function for kernel density plots).
      warnings.warn(msg, FutureWarning)
    




    <function matplotlib.pyplot.show(close=None, block=None)>




    
![png](output_26_2.png)
    


This report shows how the employees drive the term deposit. and how the drive were monitor quaterly. 
the plot shows that the employees almost 5200 drive more and achieve their aim. 


```python
# this shows the list of marital who subscribe to termdeposit. 

sns.countplot(data['marital'])
plt.show()
```

    C:\Users\USER\anaconda3\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    


    
![png](output_28_1.png)
    


This shows the number of the subscribers, who sucbcribe to term deposit. and almost married status subcribe to the term deposit and while single did and divorced follows.


```python
sns.catplot(x = 'nr.employed', y = 'euribor3m', data = data, hue = 'y', kind = 'bar'), sns.catplot(x = 'marital', y = 'euribor3m', data = data, hue = 'y', kind = 'bar'),sns.catplot(x = 'marital', y = 'age', data = data, hue = 'y', kind = 'bar') 
plt.show()
```


    
![png](output_30_0.png)
    



    
![png](output_30_1.png)
    



    
![png](output_30_2.png)
    


This first plot shows how the employees drive the term deposit and it also show how many customer subcribe to it. who are the customer that says no and those that says yes. 
almost 228.1 of the employees did well in the first quater by bringing more customer to subcribe to the term deposit. 

The second plot shows the marital status who subscribe to the term deposit. i oberserved that the married status subcribe to the term deposit due to their children, follow by the divorced status and single. married status did well in this first quater.
the married status also have the highest number of non subcribers.


the third plot analyse the marital status and the age of those who subscribe and who did not subscribe. 
i oberseve that from 0 to 42 years did not subscribe to term deposit and while 45 years old subcribe on married status. on single we have highest is 32 years old that didnt subcribe and while 29  years old avearge that subcribe. and on divorced status, average of 42 years old that did not subcribe and while average of 49 years old subscribe.




```python
# To fill in the missing numbers. and to load 
df2 = data.apply(lambda x: x.fillna(x.value_counts().index[0]))
```

missing values have to be filled by using lambda to fill the missing values. 


```python
df2.head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>job</th>
      <th>marital</th>
      <th>education</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>campaign</th>
      <th>pdays</th>
      <th>previous</th>
      <th>poutcome</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>housemaid</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>3</th>
      <td>40</td>
      <td>admin.</td>
      <td>married</td>
      <td>basic.6y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>4</th>
      <td>56</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>5</th>
      <td>45</td>
      <td>services</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>6</th>
      <td>59</td>
      <td>admin.</td>
      <td>married</td>
      <td>professional.course</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>7</th>
      <td>41</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>8</th>
      <td>24</td>
      <td>technician</td>
      <td>single</td>
      <td>professional.course</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>9</th>
      <td>25</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>10</th>
      <td>41</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>11</th>
      <td>25</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>12</th>
      <td>29</td>
      <td>blue-collar</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>13</th>
      <td>57</td>
      <td>housemaid</td>
      <td>divorced</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>14</th>
      <td>35</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.6y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>15</th>
      <td>54</td>
      <td>retired</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>16</th>
      <td>35</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.6y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>17</th>
      <td>46</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.6y</td>
      <td>no</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>18</th>
      <td>50</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>19</th>
      <td>39</td>
      <td>management</td>
      <td>single</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>20</th>
      <td>30</td>
      <td>unemployed</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>21</th>
      <td>55</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>22</th>
      <td>55</td>
      <td>retired</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>23</th>
      <td>41</td>
      <td>technician</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>24</th>
      <td>37</td>
      <td>admin.</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>25</th>
      <td>35</td>
      <td>technician</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>26</th>
      <td>59</td>
      <td>technician</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>27</th>
      <td>39</td>
      <td>self-employed</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>28</th>
      <td>54</td>
      <td>technician</td>
      <td>single</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>2</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>29</th>
      <td>55</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>30</th>
      <td>46</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>31</th>
      <td>59</td>
      <td>technician</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>32</th>
      <td>49</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>33</th>
      <td>54</td>
      <td>management</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>34</th>
      <td>54</td>
      <td>blue-collar</td>
      <td>divorced</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>35</th>
      <td>55</td>
      <td>admin.</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>36</th>
      <td>34</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>37</th>
      <td>52</td>
      <td>technician</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>38</th>
      <td>41</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>39</th>
      <td>56</td>
      <td>technician</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>40</th>
      <td>58</td>
      <td>management</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>41</th>
      <td>32</td>
      <td>entrepreneur</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>42</th>
      <td>38</td>
      <td>admin.</td>
      <td>single</td>
      <td>professional.course</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>43</th>
      <td>57</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>44</th>
      <td>44</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>45</th>
      <td>42</td>
      <td>technician</td>
      <td>single</td>
      <td>professional.course</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>46</th>
      <td>57</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>47</th>
      <td>40</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>48</th>
      <td>35</td>
      <td>admin.</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
    <tr>
      <th>49</th>
      <td>45</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>2</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>no</td>
    </tr>
  </tbody>
</table>
<p>50 rows × 21 columns</p>
</div>



It shows the missing values have be filled. and all missing values has been replaced. 


```python
# To show if there is any missing values. 
df2.isnull().sum()
```




    age               0
    job               0
    marital           0
    education         0
    default           0
    housing           0
    loan              0
    contact           0
    month             0
    day_of_week       0
    duration          0
    campaign          0
    pdays             0
    previous          0
    poutcome          0
    emp.var.rate      0
    cons.price.idx    0
    cons.conf.idx     0
    euribor3m         0
    nr.employed       0
    y                 0
    dtype: int64




```python
# To drop some of the variables. 
df2 = df2.drop(['emp.var.rate','euribor3m', 'nr.employed'], axis = 1 )
```

i dropped emp.var.rate','euribor3m', 'nr.employed because they have a high correlation and it wont give a perfect result for the model. we have to drop them. 


```python
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>job</th>
      <th>marital</th>
      <th>education</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>duration</th>
      <th>campaign</th>
      <th>pdays</th>
      <th>previous</th>
      <th>poutcome</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>housemaid</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>261</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>no</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>149</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>no</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>226</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>no</td>
    </tr>
    <tr>
      <th>3</th>
      <td>40</td>
      <td>admin.</td>
      <td>married</td>
      <td>basic.6y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>151</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>no</td>
    </tr>
    <tr>
      <th>4</th>
      <td>56</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>307</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>no</td>
    </tr>
  </tbody>
</table>
</div>




```python
#To change the categories to numeric.

df3= pd.get_dummies(df2, drop_first=True)
```


```python
df3.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>duration</th>
      <th>campaign</th>
      <th>pdays</th>
      <th>previous</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>job_blue-collar</th>
      <th>job_entrepreneur</th>
      <th>job_housemaid</th>
      <th>...</th>
      <th>month_nov</th>
      <th>month_oct</th>
      <th>month_sep</th>
      <th>day_of_week_mon</th>
      <th>day_of_week_thu</th>
      <th>day_of_week_tue</th>
      <th>day_of_week_wed</th>
      <th>poutcome_nonexistent</th>
      <th>poutcome_success</th>
      <th>y_yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>261</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>149</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>226</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>40</td>
      <td>151</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>56</td>
      <td>307</td>
      <td>1</td>
      <td>999</td>
      <td>0</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 45 columns</p>
</div>



the categorical are changed to numeric for the model to perform well


```python
#to get our features and target. 
features = df3.drop('y_yes', axis =1)
target = df3['y_yes']



```

features and target are to be used, by dropping yyes and for me to build my model.


```python
target.value_counts()
```




    0    36548
    1     4640
    Name: y_yes, dtype: int64



this is the imbalanced data. and i want to build on it 


```python
# To build on imbalanced data 
```


```python
# To split into train and test split.
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(features, target, test_size = 0.25, random_state = 0)
X_train, x_val, Y_train, y_val = train_test_split(X_train, Y_train, random_state = 0)

```

splitting the model into train and test split to build my model. 
i will love to use xtrain and xval to get my best parameter before testing my xtest on my model. 


```python
# To get the shape of the xtrain xtest xval
X_train.shape, X_test.shape, x_val.shape
```




    ((23168, 44), (10297, 44), (7723, 44))




```python
# to standardise our model, fitting it to what we want. 
from sklearn.preprocessing import StandardScaler,MinMaxScaler

scaler = StandardScaler()

X_train_std = scaler.fit_transform(X_train)
x_val_std = scaler.transform(x_val)
X_test_std = scaler.transform(X_test)
```


```python
# Building our model with logistic regression. 
from sklearn.linear_model import LogisticRegression

logreg = LogisticRegression()
logreg.fit(X_train_std, Y_train)
print("Train accuracy: {:.4f}".format(logreg.score(X_train_std, Y_train)))
print("Validation accuracy: {:.4f}".format(logreg.score(x_val_std, y_val)))
```

    Train accuracy: 0.9056
    Validation accuracy: 0.9092
    


```python
#Building our model with Decision tree. 
from sklearn.tree import DecisionTreeClassifier

tree = DecisionTreeClassifier(max_depth = 5)
tree.fit(X_train_std, Y_train)
print("Train accuracy: {:.4f}".format(tree.score(X_train_std, Y_train)))
print("Validation accuracy: {:.4f}".format(tree.score(x_val_std, y_val))) 
```

    Train accuracy: 0.9120
    Validation accuracy: 0.9107
    


```python
#Building our model with k neighbour . 
from sklearn.neighbors import KNeighborsClassifier

knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train_std, Y_train)
print("Train accuracy: {:.4f}".format(knn.score(X_train_std, Y_train)))
print("Validation accuracy: {:.4f}".format(knn.score(x_val_std, y_val)))
```

    Train accuracy: 0.9179
    Validation accuracy: 0.8965
    


```python
#Building our model with random forest . 
from sklearn.ensemble import RandomForestClassifier
forest =RandomForestClassifier(n_estimators = 5, criterion = 'entropy', random_state = 0)
forest.fit(X_train_std,Y_train)
print("Train accuracy: {:.4f}".format(forest.score(X_train_std, Y_train)))
print("Validation accuracy: {:.4f}".format(forest.score(x_val_std, y_val)))
```

    Train accuracy: 0.9878
    Validation accuracy: 0.9031
    


```python
# Using hypher parameters to fine tune out logstic regression. 
values_of_c = [0.10, 0.30, 0.05, 0.1, 0.25, 0.20, 0.25, 0.05, 0.67, 0.8]

train_accuracy = []
validation_accuracy = []

import matplotlib.pyplot as plt 

for C in values_of_c:
    logreg = LogisticRegression()
    logreg.fit(X_train_std, Y_train)
    train_accuracy.append(logreg.score(X_train_std, Y_train))
    validation_accuracy.append(logreg.score(x_val_std, y_val))
    
plt.plot(values_of_c, train_accuracy, label = "Training Accuracy")
plt.plot(values_of_c, validation_accuracy, label= "Validation Accuracy")
plt.legend()
plt.xlabel('values_of_C')
plt.ylabel('Accuracies')
plt.show()
```


    
![png](output_56_0.png)
    



```python
#Rebuilding our model with logistic regression . 
logreg1 = LogisticRegression (C= 0.8)

logreg1.fit(X_train_std, Y_train)
print("Train accuracy: {:.4f}".format(logreg1.score(X_train_std, Y_train)))
print("Validation accuracy: {:.4f}".format(logreg1.score(x_val_std, y_val)))
```

    Train accuracy: 0.9056
    Validation accuracy: 0.9092
    


```python
#Building our model with gridsearch . 
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.preprocessing import StandardScaler,MinMaxScaler
X_train, X_test, Y_train, Y_test = train_test_split(features, target, test_size = 0.25, random_state = 0)
X_train, x_val, Y_train, y_val = train_test_split(X_train, Y_train, random_state = 0)

param_grid = {'C':[0.10, 0.30, 0.05, 0.1, 0.25, 0.20, 0.25, 0.05, 0.67, 0.8]}
    
logreg1 = LogisticRegression()

scaler = StandardScaler()

X_train_std = scaler.fit_transform(X_train)
x_val_std = scaler.transform(x_val)
X_test_std = scaler.transform(X_test)

grid = RandomizedSearchCV(logreg1, param_grid, cv = 5,  n_jobs = -1,)

grid.fit(X_train_std, Y_train)

print("train in Gridsearch: {:.4f}".format(grid.score(X_train_std, Y_train)))
print("best score on validation: {:.4f}".format(grid.best_score_))
print("best parameters: {}".format(grid.best_params_))
```

    train in Gridsearch: 0.9057
    best score on validation: 0.9052
    best parameters: {'C': 0.2}
    


```python
#Checking the parameter with clasification report, f1 score, recallscore. 
from sklearn.metrics import classification_report, f1_score, recall_score, precision_score, confusion_matrix

y_pred = forest.predict(X_test_std)

conf = confusion_matrix(Y_test, y_pred)

class_report = classification_report(Y_test, y_pred)

recall = recall_score(Y_test, y_pred)

precision = precision_score(Y_test, y_pred)   

fmeasure = f1_score(Y_test, y_pred)
```


```python
data4 = print("confusion matrix: \n{}".format(conf)), print("recall_score: \n{}".format(recall)), print("classification_report: \n{}".format(class_report))
```

    confusion matrix: 
    [[8444  573]
     [ 522 8735]]
    recall_score: 
    0.9436102408987793
    classification_report: 
                  precision    recall  f1-score   support
    
               0       0.94      0.94      0.94      9017
               1       0.94      0.94      0.94      9257
    
        accuracy                           0.94     18274
       macro avg       0.94      0.94      0.94     18274
    weighted avg       0.94      0.94      0.94     18274
    
    


```python
#to balance data 
import imblearn
from imblearn.over_sampling import SMOTE

smote = SMOTE()

features_smote, target_smote = smote.fit_resample(features, target)
```

building on a balanced data 


```python
target_smote.value_counts()
```




    1    36548
    0    36548
    Name: y_yes, dtype: int64




```python
# To split the dataset into train and test split.
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(features_smote, target_smote, test_size = 0.25, random_state = 0)
X_train, x_val, Y_train, y_val = train_test_split(X_train, Y_train, random_state = 0)
```


```python
# To scale the dataset
from sklearn.preprocessing import StandardScaler,MinMaxScaler

scaler = StandardScaler()

X_train_std = scaler.fit_transform(X_train)
x_val_std = scaler.transform(x_val)
X_test_std = scaler.transform(X_test)
```


```python
# To build my dataset with logistic regression. 
from sklearn.linear_model import LogisticRegression

logreg = LogisticRegression()
logreg.fit(X_train_std, Y_train)
print("Train accuracy: {:.4f}".format(logreg.score(X_train_std, Y_train)))
print("Validation accuracy: {:.4f}".format(logreg.score(x_val_std, y_val)))
```

    Train accuracy: 0.9340
    Validation accuracy: 0.9351
    


```python
# # To build my dataset with Decision tree.
from sklearn.tree import DecisionTreeClassifier

tree = DecisionTreeClassifier(max_depth= 5)
tree.fit(X_train_std, Y_train)
print("Train accuracy: {:.4f}".format(tree.score(X_train_std, Y_train)))
print("Validation accuracy: {:.4f}".format(tree.score(x_val_std, y_val))) 
```

    Train accuracy: 0.8681
    Validation accuracy: 0.8671
    


```python
# To build my dataset with random forest.
from sklearn.ensemble import RandomForestClassifier
forest =RandomForestClassifier(n_estimators = 5, criterion = 'entropy', random_state = 0)
forest.fit(X_train_std,Y_train)
print("Train accuracy: {:.4f}".format(forest.score(X_train_std, Y_train)))
print("Validation accuracy: {:.4f}".format(forest.score(x_val_std, y_val)))
```

    Train accuracy: 0.9934
    Validation accuracy: 0.9404
    


```python
# To build my dataset with kneighbor.
from sklearn.neighbors import KNeighborsClassifier
 
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train_std, Y_train)
print("Train accuracy: {:.4f}".format(knn.score(X_train_std, Y_train)))
print("Validation accuracy: {:.4f}".format(knn.score(x_val_std, y_val)))
```

    Train accuracy: 0.9451
    Validation accuracy: 0.9327
    


```python
# to use hyper parameter to fine tune our data set. 
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.preprocessing import StandardScaler,MinMaxScaler
X_train, X_test, Y_train, Y_test = train_test_split(features_smote, target_smote, test_size = 0.25, random_state = 0)
X_train, x_val, Y_train, y_val = train_test_split(X_train, Y_train, random_state = 0)

param_grid = {'C':[0.10, 0.30, 0.5, 0.1, 0.25, 0.20, 0.35, 0.45, 0.67, 0.8]}
    
logreg2 = LogisticRegression()

scaler = StandardScaler()

X_train_std = scaler.fit_transform(X_train)
x_val_std = scaler.transform(x_val)
X_test_std = scaler.transform(X_test)

grid = RandomizedSearchCV(logreg2, param_grid, cv = 5,  n_jobs = -1,)

grid.fit(X_train_std, Y_train)

print("train in Gridsearch: {:.4f}".format(grid.score(X_train_std, Y_train)))
print("best score on validation: {:.4f}".format(grid.best_score_))
print("best parameters: {}".format(grid.best_params_))
```

    train in Gridsearch: 0.9340
    best score on validation: 0.9335
    best parameters: {'C': 0.5}
    


```python
# Getting the final result with out xtest and our best parameter. 
logreg2 = LogisticRegression (C= 0.2)

logreg2.fit(X_train_std, Y_train)
print("Test accuracy: {:.4f}".format(logreg2.score(X_test_std, Y_test)))
print("train accuracy: {:.4f}".format(logreg2.score(X_train_std, Y_train)))
```

    Test accuracy: 0.9312
    train accuracy: 0.9340
    


```python
#Checking the parameter with clasification report, f1 score, recallscore.
from sklearn.metrics import classification_report, f1_score, recall_score, precision_score, confusion_matrix

y_pred = forest.predict(X_test_std)

conf = confusion_matrix(Y_test, y_pred)

class_report = classification_report(Y_test, y_pred)

recall = recall_score(Y_test, y_pred)

precision = precision_score(Y_test, y_pred)   

fmeasure = f1_score(Y_test, y_pred)
```


```python
data5 = print("recall_score: \n{}".format(recall)), print("confusion matrix: \n{}".format(conf)),print("classification_report: \n{}".format(class_report))
```

    recall_score: 
    0.9436102408987793
    confusion matrix: 
    [[8444  573]
     [ 522 8735]]
    classification_report: 
                  precision    recall  f1-score   support
    
               0       0.94      0.94      0.94      9017
               1       0.94      0.94      0.94      9257
    
        accuracy                           0.94     18274
       macro avg       0.94      0.94      0.94     18274
    weighted avg       0.94      0.94      0.94     18274
    
    


```python
import pickle
import joblib
```


```python
filename = 'logreg2.pkl'

file = open(filename, 'wb')
pickle.dump(logreg2, file)
file.close()
```

# SUMMARY OF MY PROJECT.
 i build my model with series of models i use logistic regression, decision tree, random forest, knneigbhour. I build my model on imbalanced data and a balanced data to know how well my model can work. on the balanced and imblanaced data on logistic. my result is Train accuracy: 0.9056 Validation accuracy: 0.9092 for imbalance data and on balanced data, Train accuracy: 0.9340 Validation accuracy: 0.9351.On decision tree: Train accuracy: 0.9120 Validation accuracy: 0.9107, while on balance data we have Train accuracy: 0.8681 Validation accuracy: 0.8671. on random forest:Train accuracy: 0.9878 Validation accuracy: 0.9031 on balanced data: Train accuracy: 0.9934 Validation accuracy: 0.9404. on knneigbhour: Train accuracy: 0.9179 Validation accuracy: 0.8965 on balanced data: Train accuracy: 0.9451 Validation accuracy: 0.9327 i did hyperparameter tunning on my model, by using the best model which is the logistic regression. on the balance data and also on the imbalance data.
Then. i prepare to use the logistic because my model performed well on it and after using the gridsearch to tune my model on the balanced and imbalanced data. logistic regression  peformed perfectly well giving train in Gridsearch: 0.9340
best score on validation: 0.9335
best parameters: {'C': 0.5} on my balanced data. 

i rebuild my model with logistic after tunning with grid search on my balanced data and i got Test accuracy: 0.9312
train accuracy: 0.9340
    
my classification_report, f1_score, recall_score, precision_score, confusion_matrix also perfrom better with a good result of recall_score: 
0.9436102408987793
confusion matrix: 
[[8444  573]
 [ 522 8735]]
classification_report: 
              precision    recall  f1-score   support

           0       0.94      0.94      0.94      9017
           1       0.94      0.94      0.94      9257

    accuracy                           0.94     18274
   macro avg       0.94      0.94      0.94     18274
weighted avg       0.94      0.94      0.94     18274

This model will work more better and fast. 




```python

```
